//! Backend selection and validation configuration.

const std = @import("std");
const builtin = @import("builtin");
const Instance = @import("instance.zig").Instance;
const Adapter = @import("adapter.zig").Adapter;

/// Top-level configuration used while selecting an adapter.
pub const VitellusConfig = struct {
    /// Optional name shown for the backend instance in graphics debuggers.
    label: ?[]const u8 = null,
    /// Optional set of built-in backends the caller is willing to use.
    ///
    /// If null, Vitellus uses the current platform's preferred fallback chain:
    /// - Windows: DX12 → Vulkan
    /// - Apple platforms: Metal → Vulkan
    /// - Android: Vulkan
    /// - Linux: Vulkan
    /// - Web (Emscripten): WebGPU
    ///
    /// When set to `vulkan`, `dx12`, or `metal`, the `VITELLUS_BACKEND`
    /// environment variable promotes that backend to the front of the
    /// fallback chain when it is included in this set.
    ///
    /// Pass an empty set (`.{}`) together with `custom_backends` to disable
    /// every built-in backend.
    backend: ?BackendType,
    /// User-implemented backends tried, in listed order, before any built-in
    /// backend. See `BackendFactory`.
    custom_backends: []const BackendFactory = &.{},
    /// Validation features requested from the selected backend.
    validation: ValidationLevel,
};

/// Rendering backend implemented by Vitellus, or a user-implemented one.
pub const Backend = union(enum) {
    dx12,
    vulkan,
    metal,
    /// WebGPU in the browser, through Emscripten.
    webgpu,
    /// User-implemented backend identified by a stable, unique name
    /// (e.g. "software"). The name is borrowed and must outlive this value.
    custom: []const u8,

    /// Returns whether two backend identities are the same. Custom backends
    /// compare by name.
    pub fn eql(self: Backend, other: Backend) bool {
        if (std.meta.activeTag(self) != std.meta.activeTag(other)) return false;
        return switch (self) {
            .custom => |name_| std.mem.eql(u8, name_, other.custom),
            else => true,
        };
    }

    /// Returns a stable, human-readable backend name.
    pub fn name(self: Backend) []const u8 {
        return switch (self) {
            .custom => |n| n,
            else => @tagName(self),
        };
    }
};

/// Entry point for a user-implemented rendering backend.
///
/// A backend implements the type-erased vtables from `interface/` (`Instance`,
/// `Adapter`, `Device`, `Queue`, ...) and exposes itself with a factory:
///
/// ```zig
/// pub const factory = vitellus.BackendFactory{
///     .name = "software",
///     .createInstanceFn = SoftwareInstance.create,
/// };
/// ```
///
/// Callers opt in through `VitellusConfig.custom_backends`:
///
/// ```zig
/// const instance = try vitellus.Instance.init(allocator, .{
///     .backend = .{}, // or a built-in set to fall back to
///     .custom_backends = &.{software.factory},
///     .validation = .none,
/// });
/// ```
pub const BackendFactory = struct {
    /// Stable, unique backend name (e.g. "software"). This is the identity the
    /// backend should use as `Backend{ .custom = name }` in shader compile
    /// requests.
    name: []const u8,
    /// Creates the backend's `Instance`. Return an error to let selection
    /// fall through to the next candidate backend.
    createInstanceFn: *const fn (allocator: std.mem.Allocator, config: VitellusConfig) anyerror!Instance,
    /// Optionally enumerates every adapter exposed by the backend. Used by
    /// `Adapter.enumerateCustom`.
    enumerateAdaptersFn: ?*const fn (allocator: std.mem.Allocator) anyerror![]Adapter = null,

    /// Returns this backend's identity.
    pub fn backend(self: BackendFactory) Backend {
        return .{ .custom = self.name };
    }
};

/// Set of backends a caller is willing to use.
pub const BackendType = packed struct(u32) {
    vulkan: bool = false,
    dx12: bool = false,
    metal: bool = false,
    webgpu: bool = false,
    _pad: u28 = 0,

    /// Returns a set containing every known backend.
    ///
    /// Currently the rules are:
    /// - Windows:
    ///     - DirectX 12
    ///     - Vulkan
    /// - Linux:
    ///     - Vulkan
    /// - macOS:
    ///     - Metal
    ///     - Vulkan
    /// - Web (Emscripten):
    ///     - WebGPU
    pub fn all() BackendType {
        return .{ .vulkan = true, .dx12 = true, .metal = true, .webgpu = true };
    }

    /// Returns whether this set contains `backend`. Custom backends are
    /// selected through `VitellusConfig.custom_backends`, never this set.
    pub fn contains(self: BackendType, backend: Backend) bool {
        return switch (backend) {
            .dx12 => self.dx12,
            .vulkan => self.vulkan,
            .metal => self.metal,
            .webgpu => self.webgpu,
            .custom => false,
        };
    }

    /// Returns whether no backend is enabled.
    pub fn isEmpty(self: BackendType) bool {
        return !self.dx12 and !self.vulkan and !self.metal and !self.webgpu;
    }
};

/// Parses a built-in backend name, returning null for unknown names.
pub fn parseBackendName(name: []const u8) ?Backend {
    if (std.mem.eql(u8, name, "vulkan")) return .vulkan;
    if (std.mem.eql(u8, name, "dx12")) return .dx12;
    if (std.mem.eql(u8, name, "metal")) return .metal;
    if (std.mem.eql(u8, name, "webgpu")) return .webgpu;
    return null;
}

fn processEnviron() std.process.Environ {
    const Block = std.process.Environ.Block;
    if (comptime @hasField(Block, "use_global")) {
        return .{ .block = .global };
    }
    if (!builtin.link_libc) return .empty;
    const raw = std.c.environ;
    var env_count: usize = 0;
    while (raw[env_count] != null) : (env_count += 1) {}
    return .{ .block = .{ .slice = raw[0..env_count :null] } };
}

/// Returns the backend requested through `VITELLUS_BACKEND`, if any.
pub fn environmentBackend(allocator: std.mem.Allocator) !?Backend {
    const environ = processEnviron();
    const value = environ.getAlloc(allocator, "VITELLUS_BACKEND") catch |err| switch (err) {
        error.EnvironmentVariableMissing => return null,
        else => return err,
    };
    defer allocator.free(value);

    const backend = parseBackendName(value) orelse {
        std.log.warn("ignoring unknown VITELLUS_BACKEND value '{s}'", .{value});
        return null;
    };
    return backend;
}

/// Fixed-capacity backend preference list.
pub const BackendFallbackOrder = struct {
    items: [4]Backend = undefined,
    len: usize = 0,

    /// Returns the initialised entries in preference order.
    pub fn slice(self: *const BackendFallbackOrder) []const Backend {
        return self.items[0..self.len];
    }
};

/// Returns the backends normally considered on the target platform.
pub fn platformDefaultBackends() BackendType {
    return switch (builtin.target.os.tag) {
        .windows => .{ .dx12 = true, .vulkan = true },
        // Zig models Android as Linux with an Android ABI. Vulkan is the only backend.
        .linux => .{ .vulkan = true },
        .emscripten => .{ .webgpu = true },
        else => if (builtin.target.os.tag.isDarwin())
            .{ .metal = true, .vulkan = true }
        else
            .{ .vulkan = true },
    };
}

/// Returns platform backends from most to least preferred.
pub fn platformBackendOrder() []const Backend {
    return switch (builtin.target.os.tag) {
        .windows => &.{ .dx12, .vulkan },
        // Zig models Android as a Linux OS with an Android ABI.
        .linux => &.{.vulkan},
        .emscripten => &.{.webgpu},
        else => if (builtin.target.os.tag.isDarwin())
            &.{ .metal, .vulkan }
        else
            &.{.vulkan},
    };
}

/// Returns the ordered backends to try for this platform, filtered by the
/// caller's requested backend set. If `requested` is null, the platform default
/// fallback set is used.
pub fn backendFallbackOrder(requested: ?BackendType) BackendFallbackOrder {
    return backendFallbackOrderWithPreference(requested, null);
}

/// Returns the ordered backends to try, promoting `preferred` when it is in
/// the requested set. The remaining backends retain platform preference order.
pub fn backendFallbackOrderWithPreference(
    requested: ?BackendType,
    preferred: ?Backend,
) BackendFallbackOrder {
    const allowed = requested orelse platformDefaultBackends();
    var order = BackendFallbackOrder{};

    if (allowed.isEmpty()) return order;

    if (preferred) |backend| {
        if (allowed.contains(backend)) {
            order.items[order.len] = backend;
            order.len += 1;
        }
    }

    for (platformBackendOrder()) |backend| {
        if (preferred) |preferred_backend| {
            if (backend.eql(preferred_backend)) continue;
        }
        if (allowed.contains(backend)) {
            order.items[order.len] = backend;
            order.len += 1;
        }
    }

    return order;
}

test "built-in backend names can be parsed" {
    try std.testing.expect(parseBackendName("vulkan").?.eql(.vulkan));
    try std.testing.expect(parseBackendName("dx12").?.eql(.dx12));
    try std.testing.expect(parseBackendName("metal").?.eql(.metal));
    try std.testing.expectEqual(@as(?Backend, null), parseBackendName("unknown"));
}

test "preferred backend is first in fallback order" {
    const order = backendFallbackOrderWithPreference(BackendType.all(), .metal);
    try std.testing.expect(order.len > 0);
    try std.testing.expect(order.slice()[0].eql(.metal));
}

/// Amount of backend and API validation requested by the application.
pub const ValidationLevel = enum { none, core, extended, gpu_based };

/// Optional capabilities that must be checked before device creation.
pub const FeatureSet = packed struct(u32) {
    timestamp_query: bool = false,
    occlusion_query: bool = false,
    indirect_first_instance: bool = false,
    depth_clip_control: bool = false,
    wireframe: bool = false,
    anisotropic_filtering: bool = false,
    bc_compression: bool = false,
    _pad: u25 = 0,
};
