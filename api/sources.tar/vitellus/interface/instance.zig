const std = @import("std");
const options = @import("shader_options");
const settings = @import("settings.zig");
const Backend = settings.Backend;
const VitellusConfig = settings.VitellusConfig;
const Adapter = @import("adapter.zig").Adapter;
const AdapterDescriptor = @import("adapter.zig").AdapterDescriptor;

pub const Instance = struct {
    ptr: *anyopaque,
    vtable: *const VTable,
    allocator: std.mem.Allocator,
    config: VitellusConfig = undefined,
    selected_backend: Backend = undefined,

    pub const VTable = struct {
        deinitFn: *const fn (ptr: *anyopaque, allocator: std.mem.Allocator) void,
        createAdapterFn: *const fn (ptr: *anyopaque, allocator: std.mem.Allocator, desc: AdapterDescriptor) anyerror!Adapter,
        enumerateAdaptersFn: ?*const fn (ptr: *anyopaque, allocator: std.mem.Allocator) anyerror![]Adapter = null,
    };

    /// Start the first backend that works, in the order `config.backend` and the
    /// `VITELLUS_BACKEND` environment variable choose; `backend` says which it was. Returns the
    /// last backend's error when none starts.
    pub fn init(allocator: std.mem.Allocator, config: VitellusConfig) !Instance {
        var last_error: anyerror = error.NoSupportedBackend;
        var buffer: [settings.platform_backends.len]Backend = undefined;
        for (settings.backendOrder(&buffer, config.backend, try settings.environmentBackend(allocator))) |candidate| {
            // Typed so the catch still compiles when every built-in backend is disabled.
            var instance = @as(anyerror!Instance, switch (candidate) {
                .dx12 => if (comptime options.enable_dx12)
                    @import("../backends/dx12/instance.zig").Dx12Instance.init(allocator, config)
                else
                    error.Dx12Unavailable,
                .vulkan => if (comptime options.enable_vk)
                    @import("../backends/vulkan/instance.zig").vkInstance.init(allocator, config)
                else
                    error.VulkanUnavailable,
                .metal => error.MetalNotImplemented,
                .webgpu => if (comptime options.enable_webgpu)
                    @import("../backends/webgpu.zig").createInstance(allocator, config)
                else
                    error.WebGpuUnavailable,
            }) catch |err| {
                last_error = err;
                continue;
            };
            instance.config = config;
            instance.selected_backend = candidate;
            return instance;
        }
        return last_error;
    }

    /// Shut the backend down, after every adapter made from it.
    pub fn deinit(self: Instance) void {
        self.vtable.deinitFn(self.ptr, self.allocator);
    }

    /// Pick a GPU; `Adapter.init` is the usual way to call this.
    pub fn createAdapter(self: Instance, desc: AdapterDescriptor) !Adapter {
        return self.vtable.createAdapterFn(self.ptr, self.allocator, desc);
    }

    /// Enumerates every adapter exposed by this instance's selected backend.
    ///
    /// The caller owns the returned slice and every adapter in it. Destroy
    /// dependent objects first, call `deinit` on each adapter, then free the
    /// slice with the instance allocator before deinitialising the instance.
    pub fn enumerateAdapters(self: Instance) ![]Adapter {
        const enumerateFn = self.vtable.enumerateAdaptersFn orelse
            return error.EnumerationUnsupported;
        const adapters = try enumerateFn(self.ptr, self.allocator);
        for (adapters) |*adapter| {
            adapter.validation = self.config.validation;
        }
        return adapters;
    }

    /// The backend `init` started.
    pub fn backend(self: Instance) Backend {
        return self.selected_backend;
    }
};

test "DX12 instance owns a factory" {
    if (@import("builtin").target.os.tag != .windows) return error.SkipZigTest;
    const instance = try Instance.init(std.testing.allocator, .{
        .backend = .{ .dx12 = true },
        .validation = .none,
    });
    defer instance.deinit();
    const adapter = try instance.createAdapter(.{});
    adapter.deinit();
}

test "DX12 instance enumerates selectable adapters" {
    if (@import("builtin").target.os.tag != .windows) return error.SkipZigTest;
    const instance = try Instance.init(std.testing.allocator, .{
        .backend = .{ .dx12 = true },
        .validation = .none,
    });
    defer instance.deinit();

    const adapters = try instance.enumerateAdapters();
    defer {
        for (adapters) |adapter| adapter.deinit();
        std.testing.allocator.free(adapters);
    }

    try std.testing.expect(adapters.len > 0);
    try std.testing.expectEqual(settings.ValidationLevel.none, adapters[0].validation);
}

test "an empty backend set selects nothing" {
    try std.testing.expectError(error.NoSupportedBackend, Instance.init(std.testing.allocator, .{ .backend = .{}, .validation = .none }));
}

// Doc tests below: Zig's generated docs show each one as its type's example, and
// `zig build test` runs it, on the machine's GPU when it has one.
const vit = @import("../root.zig");
const ExampleGpu = @import("example_gpu.zig");

test Instance {
    // One instance per app. Vitellus takes the platform's first backend that works; set
    // `.backend` to narrow the choice and `.validation` to have the API check every call.
    const instance = vit.Instance.init(std.testing.allocator, .{ .validation = .none }) catch return error.SkipZigTest;
    defer instance.deinit();

    // Every GPU the backend can use, for a settings menu. A browser offers only one, so
    // WebGPU can't list them.
    const adapters = instance.enumerateAdapters() catch return error.SkipZigTest;
    defer {
        for (adapters) |adapter| adapter.deinit();
        std.testing.allocator.free(adapters);
    }
    for (adapters) |adapter| try std.testing.expect(adapter.info().nameSlice().len > 0);
    try std.testing.expect(instance.backend() != .metal);
}
