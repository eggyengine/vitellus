const std = @import("std");
const Queue = @import("../../interface/queue.zig").Queue;
const QueueDescriptor = @import("../../interface/queue.zig").QueueDescriptor;
const QueueKind = @import("../../interface/queue.zig").QueueKind;
const device_mod = @import("device.zig");
const Dx12Device = device_mod.Dx12Device;
const dx = @import("dx12_c");
const utils = @import("utils.zig");
const ComPtr = utils.ComPtr;
const checkHr = utils.checkHr;
const sync = @import("sync.zig");

const log = std.log.scoped(.dx12_queue);

pub const Dx12Queue = struct {
    queue: ComPtr(dx.ID3D12CommandQueue) = .{},
    fence: ComPtr(dx.ID3D12Fence) = .{},
    fence_value: u64 = 0,
    kind: QueueKind = .graphics,
    /// Asked why it was removed when a call on this queue reports `DeviceLost`.
    device: *dx.ID3D12Device = undefined,

    const vtable: Queue.VTable = .{
        .deinitFn = deinitImpl,
        .submitFn = sync.submit,
        .waitIdleFn = sync.waitIdle,
    };

    /// `Queue.init` for DirectX 12: a command queue of `desc.kind`, with a fence for `waitIdle`.
    pub fn init(device_ptr: *anyopaque, allocator: std.mem.Allocator, desc: QueueDescriptor) !Queue {
        const self = try allocator.create(Dx12Queue);
        self.* = .{ .kind = desc.kind };
        errdefer {
            self.fence.deinit();
            self.queue.deinit();
            allocator.destroy(self);
        }

        const device: *Dx12Device = @ptrCast(@alignCast(device_ptr));
        const dx_desc = dx.D3D12_COMMAND_QUEUE_DESC{
            .Type = toDxQueueKind(desc.kind),
            .Priority = desc.priority,
            .Flags = dx.D3D12_COMMAND_QUEUE_FLAG_NONE,
            .NodeMask = desc.node_mask,
        };

        log.debug("initialising ID3D12CommandQueue", .{});
        const raw_device = device.device.unwrap();
        self.device = raw_device;
        try checkHr(raw_device.lpVtbl.*.CreateCommandQueue.?(
            raw_device,
            &dx_desc,
            &dx.IID_ID3D12CommandQueue,
            @ptrCast(self.queue.put()),
        ));
        try checkHr(raw_device.lpVtbl.*.CreateFence.?(
            raw_device,
            0,
            dx.D3D12_FENCE_FLAG_NONE,
            &dx.IID_ID3D12Fence,
            @ptrCast(self.fence.put()),
        ));
        utils.setD3D12Name(allocator, self.queue.unwrap(), desc.label);
        utils.setD3D12DerivedName(allocator, self.fence.unwrap(), desc.label, "idle fence");
        log.debug("successfully initialised ID3D12CommandQueue", .{});

        return Queue{ .ptr = self, .vtable = &vtable, .allocator = allocator };
    }

    fn deinitImpl(ptr: *anyopaque, allocator: std.mem.Allocator) void {
        const self: *Dx12Queue = @ptrCast(@alignCast(ptr));
        waitIdle(self) catch {};
        self.fence.deinit();
        self.queue.deinit();
        log.debug("destroyed DX12 command queue", .{});
        allocator.destroy(self);
    }
};

/// Block until everything submitted to the queue has finished.
pub fn waitIdle(self: *Dx12Queue) !void {
    waitForQueue(self) catch |err| {
        noteLost(self, err);
        return err;
    };
}

fn waitForQueue(self: *Dx12Queue) !void {
    self.fence_value += 1;
    const queue = self.queue.unwrap();
    const fence = self.fence.unwrap();
    try checkHr(queue.lpVtbl.*.Signal.?(queue, fence, self.fence_value));
    if (fence.lpVtbl.*.GetCompletedValue.?(fence) >= self.fence_value) return;
    const event = dx.CreateEventW(null, 0, 0, null) orelse return error.CreateEventFailed;
    defer _ = dx.CloseHandle(event);
    try checkHr(fence.lpVtbl.*.SetEventOnCompletion.?(fence, self.fence_value, event));
    if (dx.WaitForSingleObject(event, dx.INFINITE) != dx.WAIT_OBJECT_0) return error.FenceWaitFailed;
}

/// Log why the device went, when `err` says it did.
pub fn noteLost(self: *const Dx12Queue, err: anyerror) void {
    if (err == error.DeviceLost) utils.logRemovedReason(self.device);
}

fn toDxQueueKind(kind: QueueKind) dx.D3D12_COMMAND_LIST_TYPE {
    return switch (kind) {
        .graphics => dx.D3D12_COMMAND_LIST_TYPE_DIRECT,
        .compute => dx.D3D12_COMMAND_LIST_TYPE_COMPUTE,
        .copy => dx.D3D12_COMMAND_LIST_TYPE_COPY,
    };
}
