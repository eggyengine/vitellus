const std = @import("std");
const vk = @import("vulkan");
const swapchain_interface = @import("../../interface/swapchain.zig");
const Swapchain = swapchain_interface.Swapchain;
const SwapchainDescriptor = swapchain_interface.SwapchainDescriptor;
const resource = @import("../../interface/resource.zig");
const resource_impl = @import("resource.zig");
const sync = @import("../../interface/sync.zig");
const sync_impl = @import("sync.zig");
const vkAdapter = @import("adapter.zig").vkAdapter;
const vkQueue = @import("queue.zig").vkQueue;
const surface_impl = @import("surface.zig");

const log = std.log.scoped(.vk_swapchain);

pub const vkSwapchain = struct {
    allocator: std.mem.Allocator,
    adapter: *vkAdapter,
    queue: *vkQueue,
    surface: vk.SurfaceKHR,
    handle: vk.SwapchainKHR = .null,
    images: []vk.Image = &.{},
    image_views: []vk.ImageView = &.{},
    view_impls: []resource_impl.vkTextureView = &.{},
    views: []resource.TextureView = &.{},
    acquire_fence: vk.Fence = .null,
    current_image: ?u32 = null,
    extent: swapchain_interface.Extent2D,
    format: swapchain_interface.SwapchainFormat,
    color_space: swapchain_interface.SwapchainColorSpace,
    present_mode: swapchain_interface.PresentMode,
    composite_alpha: swapchain_interface.CompositeAlpha,
    usage: swapchain_interface.ImageUsage,
    requested_image_count: u32,
    /// The surface transform when the swapchain was built; a rotation changes it.
    surface_transform: vk.SurfaceTransformFlagsKHR = .{},
    label: ?[]u8 = null,

    const vtable: Swapchain.VTable = .{
        .deinitFn = deinitImpl,
        .acquireNextImageFn = acquireNextImageImpl,
        .presentFn = presentImpl,
        .resizeFn = resizeImpl,
        .infoFn = infoImpl,
    };
    /// `Swapchain.init` for Vulkan: a surface on the window and a swapchain on it.
    pub fn init(adapter_ptr: *anyopaque, allocator: std.mem.Allocator, desc: SwapchainDescriptor) !Swapchain {
        const adapter: *vkAdapter = @ptrCast(@alignCast(adapter_ptr));
        const queue: *vkQueue = @ptrCast(@alignCast(desc.queue.ptr));
        const surface = try surface_impl.create(adapter.instance, desc.window);
        errdefer adapter.instance.wrapper.destroySurfaceKHR(adapter.instance.instance, surface, null);
        if (try adapter.instance.wrapper.getPhysicalDeviceSurfaceSupportKHR(
            adapter.physical_device,
            queue.family_index,
            surface,
        ) == .false) return error.QueueCannotPresent;

        const self = try allocator.create(vkSwapchain);
        self.* = .{
            .allocator = allocator,
            .adapter = adapter,
            .queue = queue,
            .surface = surface,
            .extent = desc.extent,
            .format = desc.format,
            .color_space = desc.color_space,
            .present_mode = desc.present_mode,
            .composite_alpha = desc.composite_alpha,
            .usage = desc.usage,
            .requested_image_count = desc.image_count,
        };
        errdefer {
            if (self.label) |label| allocator.free(label);
            allocator.destroy(self);
        }
        self.label = if (desc.label) |label| try allocator.dupe(u8, label) else null;
        self.acquire_fence = try queue.device.createFence(&.{}, null);
        errdefer queue.device.destroyFence(self.acquire_fence, null);
        try self.recreate(desc.extent);

        log.debug("created Vulkan swapchain with {} images at {}x{}", .{ self.images.len, self.extent.width, self.extent.height });
        return .{ .ptr = self, .vtable = &vtable, .allocator = allocator };
    }

    fn deinitImpl(ptr: *anyopaque, allocator: std.mem.Allocator) void {
        const self: *vkSwapchain = @ptrCast(@alignCast(ptr));
        _ = self.queue.device.deviceWaitIdle() catch {};
        self.releaseImages();
        if (self.handle != .null) self.queue.device.destroySwapchainKHR(self.handle, null);
        if (self.acquire_fence != .null) self.queue.device.destroyFence(self.acquire_fence, null);
        self.adapter.instance.wrapper.destroySurfaceKHR(self.adapter.instance.instance, self.surface, null);
        if (self.label) |label| allocator.free(label);
        allocator.destroy(self);
        log.debug("destroyed Vulkan swapchain", .{});
    }

    fn acquireNextImageImpl(ptr: *anyopaque, signal: ?sync.Semaphore) anyerror!swapchain_interface.AcquireResult {
        const self: *vkSwapchain = @ptrCast(@alignCast(ptr));
        const semaphore: vk.Semaphore = if (signal) |value| try sync_impl.rawSemaphore(value) else .null;
        const fence: vk.Fence = if (signal == null) self.acquire_fence else .null;
        const acquired = while (true) {
            break self.queue.device.acquireNextImageKHR(self.handle, std.math.maxInt(u64), semaphore, fence) catch |err| switch (err) {
                error.OutOfDateKHR => {
                    try resizeImpl(ptr, self.extent);
                    continue;
                },
                else => return err,
            };
        };
        if (signal == null) {
            _ = try self.queue.device.waitForFences(&.{self.acquire_fence}, .true, std.math.maxInt(u64));
            try self.queue.device.resetFences(&.{self.acquire_fence});
        }
        if (acquired.image_index >= self.views.len) return error.InvalidSwapchainImageIndex;
        self.current_image = acquired.image_index;
        return .{
            .index = acquired.image_index,
            .view = self.views[acquired.image_index],
            .status = if (acquired.result == .suboptimal_khr) .suboptimal else .optimal,
        };
    }

    fn presentImpl(ptr: *anyopaque, waits: []const sync.Semaphore) anyerror!swapchain_interface.PresentStatus {
        const self: *vkSwapchain = @ptrCast(@alignCast(ptr));
        const image_index = self.current_image orelse return error.NoAcquiredImage;
        var stack_buf: [8 * @sizeOf(vk.Semaphore)]u8 align(16) = undefined;
        var fallback: std.heap.BufferFirstAllocator = .init(&stack_buf, self.allocator);
        const allocator = fallback.allocator();
        const semaphores = try allocator.alloc(vk.Semaphore, waits.len);
        defer allocator.free(semaphores);
        for (waits, semaphores) |wait, *semaphore| semaphore.* = try sync_impl.rawSemaphore(wait);
        // ponytail: main currently presents without a binary render-finished semaphore.
        // Serialize that compatibility path until the public API supplies one.
        if (waits.len == 0) try self.queue.device.queueWaitIdle(self.queue.queue);
        const swapchains = [_]vk.SwapchainKHR{self.handle};
        const indices = [_]u32{image_index};

        const result = self.queue.device.queuePresentKHR(self.queue.queue, &.{
            .wait_semaphore_count = @intCast(semaphores.len),
            .p_wait_semaphores = if (semaphores.len == 0) null else semaphores.ptr,
            .swapchain_count = 1,
            .p_swapchains = &swapchains,
            .p_image_indices = &indices,
        }) catch |err| switch (err) {
            error.OutOfDateKHR => {
                self.current_image = null;
                try resizeImpl(ptr, self.extent);
                return .suboptimal;
            },
            else => return err,
        };
        self.current_image = null;
        // Android reports SUBOPTIMAL on every present while rotated, because we leave rotation to
        // the compositor (see `recreate`); only rebuild when the surface actually changed.
        if (result == .suboptimal_khr) {
            const caps = try self.adapter.instance.wrapper.getPhysicalDeviceSurfaceCapabilitiesKHR(self.adapter.physical_device, self.surface);
            if (caps.current_transform.toInt() == self.surface_transform.toInt()) return .optimal;
            try resizeImpl(ptr, self.extent);
            return .suboptimal;
        }
        return .optimal;
    }

    fn resizeImpl(ptr: *anyopaque, extent: swapchain_interface.Extent2D) anyerror!void {
        const self: *vkSwapchain = @ptrCast(@alignCast(ptr));
        if (extent.width == 0 or extent.height == 0) return error.InvalidExtent;
        try self.queue.device.deviceWaitIdle();
        try self.recreate(extent);
        self.current_image = null;
    }

    fn infoImpl(ptr: *anyopaque) swapchain_interface.SwapchainInfo {
        const self: *vkSwapchain = @ptrCast(@alignCast(ptr));
        return .{ .extent = self.extent, .format = self.format, .image_count = @intCast(self.images.len) };
    }

    fn recreate(self: *vkSwapchain, requested_extent: swapchain_interface.Extent2D) !void {
        const instance = self.adapter.instance;
        const caps = try instance.wrapper.getPhysicalDeviceSurfaceCapabilitiesKHR(self.adapter.physical_device, self.surface);
        const supported = try surface_impl.query(instance, self.adapter.physical_device, self.allocator, self.surface);
        defer supported.deinit();
        if (!containsFormat(supported.formats, self.format)) return error.UnsupportedSwapchainFormat;
        if (!containsPresentMode(supported.present_modes, self.present_mode)) return error.UnsupportedPresentMode;
        if (!containsCompositeAlpha(supported.composite_alpha, self.composite_alpha)) return error.UnsupportedCompositeAlpha;

        const usage = toVkUsage(self.usage);
        if (!caps.supported_usage_flags.contains(usage)) return error.UnsupportedImageUsage;
        // Identity lets the compositor rotate for us (Android); desktops are always identity anyway.
        const pre_transform: vk.SurfaceTransformFlagsKHR = if (caps.supported_transforms.identity_khr) .{ .identity_khr = true } else caps.current_transform;
        const extent = chooseExtent(caps, requested_extent, pre_transform);
        if (extent.width == 0 or extent.height == 0) return error.InvalidExtent;
        var image_count = @max(self.requested_image_count, caps.min_image_count);
        if (caps.max_image_count != 0) image_count = @min(image_count, caps.max_image_count);

        const new_handle = try self.queue.device.createSwapchainKHR(&.{
            .surface = self.surface,
            .min_image_count = image_count,
            .image_format = surface_impl.toVkFormat(self.format),
            .image_color_space = .srgb_nonlinear_khr,
            .image_extent = extent,
            .image_array_layers = 1,
            .image_usage = usage,
            .image_sharing_mode = .exclusive,
            .pre_transform = pre_transform,
            .composite_alpha = surface_impl.toVkCompositeAlpha(self.composite_alpha),
            .present_mode = surface_impl.toVkPresentMode(self.present_mode),
            .clipped = .true,
            .old_swapchain = self.handle,
        }, null);
        errdefer self.queue.device.destroySwapchainKHR(new_handle, null);

        const new_images = try self.queue.device.getSwapchainImagesAllocKHR(new_handle, self.allocator);
        errdefer self.allocator.free(new_images);
        const new_image_views = try self.allocator.alloc(vk.ImageView, new_images.len);
        errdefer self.allocator.free(new_image_views);
        var created_views: usize = 0;
        errdefer for (new_image_views[0..created_views]) |view| self.queue.device.destroyImageView(view, null);
        const new_views = try self.allocator.alloc(resource.TextureView, new_images.len);
        errdefer self.allocator.free(new_views);
        const new_view_impls = try self.allocator.alloc(resource_impl.vkTextureView, new_images.len);
        errdefer self.allocator.free(new_view_impls);

        for (new_images, 0..) |image, index| {
            const view = try self.queue.device.createImageView(&.{
                .image = image,
                .view_type = .@"2d",
                .format = surface_impl.toVkFormat(self.format),
                .components = .{ .r = .identity, .g = .identity, .b = .identity, .a = .identity },
                .subresource_range = .{
                    .aspect_mask = .{ .color = true },
                    .base_mip_level = 0,
                    .level_count = 1,
                    .base_array_layer = 0,
                    .layer_count = 1,
                },
            }, null);
            new_image_views[index] = view;
            new_view_impls[index] = .{
                .view = view,
                .image = image,
                .format = surface_impl.toVkFormat(self.format),
                .extent = extent,
            };
            new_views[index] = .{
                .handle = @intCast(@intFromPtr(&new_view_impls[index])),
                .vtable = &resource_impl.borrowed_texture_view_vtable,
            };
            created_views += 1;
        }

        self.releaseImages();
        if (self.handle != .null) self.queue.device.destroySwapchainKHR(self.handle, null);
        self.handle = new_handle;
        self.images = new_images;
        self.image_views = new_image_views;
        self.view_impls = new_view_impls;
        self.views = new_views;
        self.extent = .{ .width = extent.width, .height = extent.height };
        self.surface_transform = caps.current_transform;
        self.adapter.instance.nameObject(
            self.allocator,
            self.queue.device,
            .swapchain_khr,
            @backingInt(self.handle),
            self.label,
        );
    }

    fn releaseImages(self: *vkSwapchain) void {
        for (self.image_views) |view| self.queue.device.destroyImageView(view, null);
        if (self.image_views.len != 0) self.allocator.free(self.image_views);
        if (self.images.len != 0) self.allocator.free(self.images);
        if (self.view_impls.len != 0) self.allocator.free(self.view_impls);
        if (self.views.len != 0) self.allocator.free(self.views);
        self.image_views = &.{};
        self.images = &.{};
        self.view_impls = &.{};
        self.views = &.{};
    }
};

fn toVkUsage(usage: swapchain_interface.ImageUsage) vk.ImageUsageFlags {
    return .{
        .color_attachment = usage.render_target,
        .sampled = usage.sampled,
        .transfer_src = usage.transfer_src,
        .transfer_dst = usage.transfer_dst,
    };
}

fn chooseExtent(caps: vk.SurfaceCapabilitiesKHR, requested: swapchain_interface.Extent2D, pre_transform: vk.SurfaceTransformFlagsKHR) vk.Extent2D {
    if (caps.current_extent.width != std.math.maxInt(u32)) {
        // Without pre-rotation, a quarter-turned surface (Android) needs window-shaped images.
        // Android reports `current_extent` in the display's native orientation, except while the
        // screen turns, when it can already be turned; so take the way round `requested` (the
        // window's size) is, and only swap blindly for a square window.
        const current = caps.current_extent;
        const turned = caps.current_transform.rotate_90_khr or caps.current_transform.rotate_270_khr or
            caps.current_transform.horizontal_mirror_rotate_90_khr or caps.current_transform.horizontal_mirror_rotate_270_khr;
        if (!turned or !pre_transform.identity_khr) return current;
        const swapped = vk.Extent2D{ .width = current.height, .height = current.width };
        if (requested.width == requested.height) return swapped;
        return if ((requested.width > requested.height) == (current.width > current.height)) current else swapped;
    }
    return .{
        .width = std.math.clamp(requested.width, caps.min_image_extent.width, caps.max_image_extent.width),
        .height = std.math.clamp(requested.height, caps.min_image_extent.height, caps.max_image_extent.height),
    };
}

test "a quarter-turned surface without pre-rotation takes the window's shape, however its extent is reported" {
    const identity = vk.SurfaceTransformFlagsKHR{ .identity_khr = true };
    var caps = std.mem.zeroes(vk.SurfaceCapabilitiesKHR);
    caps.current_transform = .{ .rotate_90_khr = true };
    // Reported in the native (portrait) orientation, as Android usually does: swapped.
    caps.current_extent = .{ .width = 1080, .height = 2424 };
    try std.testing.expectEqual(vk.Extent2D{ .width = 2424, .height = 1080 }, chooseExtent(caps, .{ .width = 2424, .height = 1080 }, identity));
    // Already turned while the screen turns: kept, not swapped back to portrait.
    caps.current_extent = .{ .width = 2424, .height = 1080 };
    try std.testing.expectEqual(vk.Extent2D{ .width = 2424, .height = 1080 }, chooseExtent(caps, .{ .width = 2424, .height = 1080 }, identity));
    // Unturned surfaces use the extent as reported.
    caps.current_transform = identity;
    try std.testing.expectEqual(vk.Extent2D{ .width = 2424, .height = 1080 }, chooseExtent(caps, .{ .width = 1080, .height = 2424 }, identity));
}

fn containsFormat(values: []const swapchain_interface.SwapchainFormat, value: swapchain_interface.SwapchainFormat) bool {
    for (values) |candidate| if (candidate == value) return true;
    return false;
}

fn containsPresentMode(values: []const swapchain_interface.PresentMode, value: swapchain_interface.PresentMode) bool {
    for (values) |candidate| if (candidate == value) return true;
    return false;
}

fn containsCompositeAlpha(values: []const swapchain_interface.CompositeAlpha, value: swapchain_interface.CompositeAlpha) bool {
    for (values) |candidate| if (candidate == value) return true;
    return false;
}
